#pragma semicolon 1
#pragma newdecls required

#include <sourcemod>

#define PLUGIN_VERSION "1.0"

ConVar g_cDeathCheckSwitch, g_cDeathCheckOption;

bool g_bDeathCheckSwitch;

public Plugin myinfo =
{
	name = "l4d2_SurvivorDeathCheck",
	author = "X光",
	description = "幸存者全部死亡才算结束",
	version = PLUGIN_VERSION,
	url = "QQ群59046067"
};

public void OnPluginStart()
{
	CreateConVar("l4d2_survivor_death_check", PLUGIN_VERSION, "plugin version", FCVAR_NOTIFY|FCVAR_DONTRECORD);

	g_cDeathCheckSwitch = CreateConVar("survivor_death_check_switch", "1", "插件开关(0=关闭, 1=开启).", FCVAR_NOTIFY);
	g_cDeathCheckOption = FindConVar("director_no_death_check");
	g_cDeathCheckSwitch.AddChangeHook(ConVar_Changed);

	HookEvent("player_death", Event_PlayerDeath);	//玩家死亡事件.
	HookEvent("mission_lost", Event_MissionLost);	//任务失败事件.

	RegAdminCmd("sm_sw", CmdDeathSwitch, ADMFLAG_ROOT, "插件开关指令.");

	//AutoExecConfig(true, "l4d2_SurvivorDeathCheck");
}

void ConVar_Changed(ConVar convar, const char[] oldValue, const char[] newValue)
{
	get_cvars();
}

void get_cvars()
{
	g_bDeathCheckSwitch = g_cDeathCheckSwitch.BoolValue;
	g_bDeathCheckSwitch ? (g_cDeathCheckOption.BoolValue = true) : (g_cDeathCheckOption.BoolValue = false);
}

public void OnConfigsExecuted()
{
	get_cvars();
}

public Action CmdDeathSwitch(int client, int args)
{
	g_cDeathCheckSwitch.BoolValue = !g_bDeathCheckSwitch;
	g_bDeathCheckSwitch ? (g_cDeathCheckOption.BoolValue = true) : (g_cDeathCheckOption.BoolValue = false);
	PrintToChat(client, "\x04[提示]\x05全部死亡才算结束已\x03%s\x05.", g_bDeathCheckSwitch ? "开启" : "关闭");
	return Plugin_Handled;
}

void Event_PlayerDeath(Event event, const char[] name, bool dontBroadcast)
{
	if (!g_bDeathCheckSwitch)
		return;

	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i) && GetClientTeam(i) == 2 && IsPlayerAlive(i))
		{
			if (!g_cDeathCheckOption.BoolValue)
				g_cDeathCheckOption.BoolValue = true;

			return;
		}
	}
	g_cDeathCheckOption.BoolValue = false;
}

void Event_MissionLost(Event event, const char[] name, bool dontBroadcast)
{
	if (!g_bDeathCheckSwitch)
		return;

	g_cDeathCheckOption.BoolValue = true;
}