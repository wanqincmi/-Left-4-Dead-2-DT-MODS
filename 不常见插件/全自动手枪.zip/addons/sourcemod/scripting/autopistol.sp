#pragma semicolon 1
#pragma newdecls required

#include <sourcemod>
#include <sdkhooks>
#include <sdktools>
#include <l4d2util>
#include <colors>

bool   g_bEnable[MAXPLAYERS + 1];
bool   g_bFired[MAXPLAYERS + 1];
bool   g_bEnhancement;
bool   g_bPluginEnable;
float  g_fNextTime[MAXPLAYERS + 1];
float  g_fShootGain;
ConVar g_hEnhancement, g_hShootGain, g_hPluginEnable;

public Plugin myinfo =
{
	name		= "Auto Pistol",
	author		= "Nepkey",
	description = "使得小手枪和双枪全自动, 按鼠标中键可切换",
	version		= "1.0 - 2024.10.17",
	url			= "https://space.bilibili.com/436650372"
};

public void OnPluginStart()
{
	g_hPluginEnable = CreateConVar("l4d2_autopistol_enable", "1", "1 = 启用插件, 0 = 禁用插件", 0, true, 0.0, true, 1.0);
	g_hEnhancement	= CreateConVar("l4d2_autopistol_enhance", "0", "1 = 启用增幅, 0 = 禁用增幅", 0, true, 0.0, true, 1.0);
	g_hShootGain	= CreateConVar("l4d2_autopistol_shootgain", "0.0", "启用增幅时额外的射速提升(提高此值可能引起射击动画异常, 最好不要超过0.1)(本地服或低tick环境下可能不工作)", 0, true, 0.0);
	HookEvent("weapon_fire", WeaponFire_CallBack, EventHookMode_Pre);
	RegAdminCmd("sm_enhance", ModeChange_CMD, ADMFLAG_CONVARS, "Admin命令, 可打开或关闭增幅模式");
	AutoExecConfig(true);
}

public void OnAllPluginsLoaded()
{
	g_bEnhancement	= g_hEnhancement.BoolValue;
	g_fShootGain	= g_hShootGain.FloatValue;
	g_bPluginEnable = g_hPluginEnable.BoolValue;
	g_hEnhancement.AddChangeHook(EnhanceConVarCallBack);
	g_hShootGain.AddChangeHook(GainConVarCallBack);
	g_hPluginEnable.AddChangeHook(GainConVarCallBack);
	AdjustVerticalPunch();
}

void EnhanceConVarCallBack(ConVar convar, const char[] oldValue, const char[] newValue)
{
	g_bEnhancement = g_hEnhancement.BoolValue;
	AdjustVerticalPunch();
	CPrintToChatAll("{green}[AutoPistol]{olive}增幅开关当前状态: %s", g_bEnhancement ? "启用" : "禁用");
}

void GainConVarCallBack(ConVar convar, const char[] o, const char[] n)
{
	g_fShootGain	= g_hShootGain.FloatValue;
	g_bPluginEnable = g_hPluginEnable.BoolValue;
}

public void OnClientPostAdminCheck(int client)
{
	g_bEnable[client] = false;
	SDKHook(client, SDKHook_WeaponSwitchPost, LaserCheck);
}

void LaserCheck(int client, int weapon)
{
	if (IsPistol(weapon))
	{
		SetEntProp(weapon, Prop_Send, "m_upgradeBitVec", g_bEnable[client] && g_bEnhancement ? 4 : 0);
	}
}

Action ModeChange_CMD(int client, int args)
{
	SetConVarBool(g_hEnhancement, !g_bEnhancement);
}

void WeaponFire_CallBack(Event e, const char[] n, bool b)
{
	if (!g_bPluginEnable) return;
	int client = GetClientOfUserId(e.GetInt("userid"));
	RequestFrame(GetNextFireTime, client);
}

void GetNextFireTime(int client)
{
	int weapon = GetEntPropEnt(client, Prop_Send, "m_hActiveWeapon");
	if (g_bEnable[client] && IsPistol(weapon))
	{
		AdjustWeaponFireSpeed(client, weapon);
	}
	g_fNextTime[client] = GetEntPropFloat(weapon, Prop_Send, "m_flNextPrimaryAttack") - 0.2;
	g_bFired[client]	= true;
	// PrintToChatAll("预测下一开火时间: %.4f", g_fNextTime[client]);
}

bool CanReshoot(int client)
{
	return GetGameTime() > g_fNextTime[client];
}

public Action OnPlayerRunCmd(int client, int &buttons)
{
	if (!g_bPluginEnable) return Plugin_Continue;
	int weapon = GetEntPropEnt(client, Prop_Send, "m_hActiveWeapon");
	if (IsPistol(weapon))
	{
		if ((buttons & IN_ZOOM) && !IsReloading(weapon))
		{
			g_bEnable[client] = !g_bEnable[client];
			SetEntProp(weapon, Prop_Send, "m_iClip1", 0);
			buttons |= IN_RELOAD;
			PlayModeSound(g_bEnable[client], client);
			char info[128];
			FormatEx(info, sizeof(info), "射击模式: %s 增幅状态: %s", g_bEnable[client] ? "全自动" : "点射", g_bEnhancement ? "开启" : "关闭");
			PrintHintText(client, "%s", info);
			LaserCheck(client, weapon);
		}
		else if ((buttons & IN_ATTACK) && !IsReloading(weapon) && g_bEnable[client])
		{
			if (CanReshoot(client) && g_bFired[client])
			{
				buttons &= ~IN_ATTACK;
				g_bFired[client] = false;
				return Plugin_Changed;
			}
		}
		else if (!(buttons & IN_ATTACK))
		{
			g_bFired[client] = false;
		}
	}
	else
	{
		g_bFired[client] = false;
	}
	return Plugin_Continue;
}

bool IsReloading(int Weapon)
{
	int ReloadOffset;
	if (IsValidEntity(Weapon))
	{
		ReloadOffset = GetEntProp(Weapon, Prop_Data, "m_bInReload");
	}
	return ReloadOffset > 0 ? true : false;
}

void PlayModeSound(bool Enable, int client)
{
	char SoundPath[2][128] = { "player/orch_hit_csharp_short.wav", "ui/menu_click01.wav" };
	PrecacheSound(SoundPath[0]);
	PrecacheSound(SoundPath[1]);
	EmitSoundToClient(client, SoundPath[Enable ? 0 : 1]);
}

void AdjustWeaponFireSpeed(int client, int weapon)
{
	float fMultiple = 1.0;
	if (!IsDualWielding(client))
	{
		fMultiple += 0.13;
	}
	if (IsIncapacitated(client) && g_bEnhancement)
	{
		if (IsDualWielding(client))
		{
			fMultiple += 0.42;
		}
		else
		{
			fMultiple += 0.25;
		}
	}
	if (g_bEnhancement && g_fShootGain > 0)
	{
		fMultiple += IsDualWielding(client) ? g_fShootGain * 0.3 : g_fShootGain;
	}
	AdjustWeaponSpeed(fMultiple, weapon);
}

/* [l4d_weapon_attributes.smx] */
void AdjustVerticalPunch()
{
	char sBuffer[128];
	FormatEx(sBuffer, sizeof(sBuffer), "sm_weapon pistol verticalpunch %.2f", g_bEnhancement ? 0.9 : 2.0);
	ServerCommand(sBuffer);
}

bool IsDualWielding(int client)
{
	int weapon = GetEntPropEnt(client, Prop_Send, "m_hActiveWeapon");
	return GetEntProp(weapon, Prop_Send, "m_isDualWielding") > 0;
}

bool IsPistol(int weapon)
{
	int weaponid = IdentifyWeapon(weapon);
	return weaponid == WEPID_PISTOL;
}

void AdjustWeaponSpeed(float Amount, int weapon)
{
	float NextAttack = GetEntPropFloat(weapon, Prop_Send, "m_flNextPrimaryAttack");
	// Getting the animation cycle at zero seems to be key here, however the scar and pistols weren't seem to be getting affected
	if (GetEntProp(weapon, Prop_Send, "m_bInReload") < 1)
	{
		SetEntPropFloat(weapon, Prop_Send, "m_flPlaybackRate", Amount);
		SetEntPropFloat(weapon, Prop_Send, "m_flNextPrimaryAttack", NextAttack - ((Amount - 1.0) / 2));
	}
}