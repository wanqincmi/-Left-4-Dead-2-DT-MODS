#include <sourcemod>

public void OnPluginStart()
{
	// 获取当前端口
	char port[6];
	GetConVarString(FindConVar("hostport"), port, sizeof(port));
	
	// 根据端口设置服务器名称
	switch (StringToInt(port))
	{
		case 20740:
		{
			SetConVarString(FindConVar("hostname"), "[AC]纯净RPG★第三方服");
		}																																											
	}
}