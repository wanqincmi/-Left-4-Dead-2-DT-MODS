/*====================================================
1.0
	- Initial release
======================================================*/
#pragma newdecls required

#include <sdktools>
#include <sourcemod>
#include <dhooks>

bool bShouldReturnNonePlayer

public Plugin myinfo = 
{
	name = "The Passing character fix",
	author = "IA/NanaNana",
	description = "Fixes the bug where players with L4D1 survivors are teleported away or kicked on The Passing.",
	version = "1.0",
	url = ""
}

public void OnPluginStart()
{
	Handle h = LoadGameConfigFile("l4d2_The_Passing_character_fix"), z
	
	if(!(z = DHookCreateFromConf(h, "GetPlayerByCharacter")))
		SetFailState("Detour \"GetPlayerByCharacter\" invalid.");
	DHookEnableDetour(z, true, DH_GetPlayerByCharacter)
	
	if(!(z = DHookCreateFromConf(h, "AddSurvivorBot")))
		SetFailState("Detour \"AddSurvivorBot\" invalid.");
	DHookEnableDetour(z, false, DH_AddSurvivorBot)
	DHookEnableDetour(z, true, DH_AddSurvivorBotPost)
}

MRESReturn DH_AddSurvivorBot(int pThis, Handle hReturn, Handle hParams)
{
	if(3 < DHookGetParam(hParams, 1) < 8) bShouldReturnNonePlayer = true
}

MRESReturn DH_AddSurvivorBotPost(int pThis, Handle hReturn, Handle hParams)
{
	bShouldReturnNonePlayer = false
}

MRESReturn DH_GetPlayerByCharacter(Handle hReturn, Handle hParams)
{
	if(bShouldReturnNonePlayer)
	{
		DHookSetReturn(hReturn, 0)
		return MRES_Supercede
	}
	int i = DHookGetParam(hParams, 1)
	if(3 < i < 8)
	{
		int a = DHookGetReturn(hReturn)
		if(a < 1 || IsFakeClientInTeam4(a)) return MRES_Ignored
		Address result
		for(a = 1;a<=MaxClients;a++)
		{
			if(IsClientInGame(a) && GetClientTeam(a) == 4 && GetEntProp(a, Prop_Send, "m_survivorCharacter") == i)
			{
				result = GetEntityAddress(a)
				break
			}
		}
		DHookSetReturn(hReturn, result)
		return MRES_Supercede
	}
	return MRES_Ignored;
}

bool IsFakeClientInTeam4(int p)
{
	for(int a = 1;a<=MaxClients;a++)
	{
		if(IsClientInGame(a) && IsFakeClient(a) && GetClientTeam(a) == 4 && view_as<int>(GetEntityAddress(a)) == p) return true
	}
	return false
}