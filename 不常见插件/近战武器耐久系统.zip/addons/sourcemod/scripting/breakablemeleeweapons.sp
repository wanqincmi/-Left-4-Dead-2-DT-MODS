/* Includes */
#include <sourcemod>
#include <sdktools>
#include <l4d_stocks>
#include <sdkhooks>
#include <colors>

/* Plugin Information */
public Plugin:myinfo = 
{
	name		= "Breakable Melee Weapons",
	author		= "Buster \"Mr. Zero\" Nielsen",
	description	= "Adds a durability feature to melee weapons.",
	version		= "2.1.0",
	url		= "mrzerodk@gmail.com"
}

/* Globals */
#define DEBUG 0
#define DEBUG_TAG "BreakableMelee"

#define MAXEDICTS 2048
#define MAXENTITIES 4096

new bool:g_IsInGame[MAXPLAYERS + 1]
#define IsClientInGameCached(%1) g_IsInGame[%1]
#define SetClientIsInGameCached(%1,%2) g_IsInGame[%1] = %2

new bool:g_IsSurvivor[MAXPLAYERS + 1]
#define IsPlayerSurvivor(%1) g_IsSurvivor[%1]
#define SetPlayerIsSurvivor(%1,%2) g_IsSurvivor[%1] = %2

new bool:g_IsInfected[MAXPLAYERS + 1]
#define IsPlayerInfected(%1) g_IsInfected[%1]
#define SetPlayerIsInfected(%1,%2) g_IsInfected[%1] = %2

#define DAMAGETYPE_MELEE_WEAPON_SHARP -2145386492
#define DAMAGETYPE_MELEE_WEAPON_BLUNT 2097280
#define DAMAGETYPE_MELEE_WEAPON_SHARP_DECAPITATION -1071644668
#define DAMAGETYPE_MELEE_WEAPON_BLUNT_DECAPITATION 1075839104

#define IsDamageTypeMeleeWeapon(%1) \
	(%1 == DAMAGETYPE_MELEE_WEAPON_SHARP || \
	%1 == DAMAGETYPE_MELEE_WEAPON_BLUNT || \
	%1 == DAMAGETYPE_MELEE_WEAPON_SHARP_DECAPITATION || \
	%1 == DAMAGETYPE_MELEE_WEAPON_BLUNT_DECAPITATION)

#define IsDamageTypeMeleeDecapitation(%1) \
	(%1 == DAMAGETYPE_MELEE_WEAPON_SHARP_DECAPITATION || \
	%1 == DAMAGETYPE_MELEE_WEAPON_BLUNT_DECAPITATION)

new g_MeleeWeaponDurability[MAXENTITIES + 1] = {-1, ...}
#define GetMeleeWeaponDurability(%1) g_MeleeWeaponDurability[%1]
#define SetMeleeWeaponDurability(%1,%2) g_MeleeWeaponDurability[%1] = %2

new g_MeleeWeaponMaxDurability[MAXENTITIES + 1] = {-1, ...}
#define GetMeleeWeaponMaxDurability(%1) g_MeleeWeaponMaxDurability[%1]
#define SetMeleeWeaponMaxDurability(%1,%2) g_MeleeWeaponMaxDurability[%1] = %2

#define SOUND_MELEE_WEAPON_BREAKAGE_WOODEN 0
#define SOUND_MELEE_WEAPON_BREAKAGE_METAL 1

new const String:SOUND_MELEE_WEAPON_BREAKAGE[][] = {
	"weapons/axe/axe_break.wav", /* Wooden */
	"weapons/pan/pan_break.wav" /* Metal */
}

#define MAX(%1,%2) (%1 > %2 ? %2 : %1)

#define CLASSNAME_INFECTED "infected"
#define CLASSNAME_WITCH "witch"
#define CLASSNAME_WITCH_BRIDE "witch_bride"

new g_HealthBeforeMeleeSwing[MAXPLAYERS + 1]
#define GetHealthBeforeMeleeSwing(%1) g_HealthBeforeMeleeSwing[%1]
#define SetHealthBeforeMeleeSwing(%1,%2) g_HealthBeforeMeleeSwing[%1] = %2

new bool:g_InMapChange = true
#define IsInMapChange() g_InMapChange
#define SetIsInMapChange(%1) g_InMapChange = %1

#define CONVAR_GIVE_EMPTY_PISTOL_NAME "breakablemeleeweapons_emptypistol"
#define CONVAR_GIVE_EMPTY_PISTOL_VALUE "1"
#define CONVAR_GIVE_EMPTY_PISTOL_DESC "Whether Survivors will be handed an empty pistol on melee weapon break. 0 = Full pistol, 1 = Empty pistol"
#define CONVAR_GIVE_EMPTY_PISTOL_FLAGS FCVAR_PLUGIN
new Handle:g_ShouldEmptyPistolConvar

#define CONVAR_DEFAULT_STRENGTH_NAME "breakablemeleeweapons_defaultstrength"
#define CONVAR_DEFAULT_STRENGTH_VALUE "1200"
#define CONVAR_DEFAULT_STRENGTH_DESC "Default strength of melee weapons if not specified. 0 = Never breaks"
#define CONVAR_DEFAULT_STRENGTH_FLAGS FCVAR_PLUGIN
new g_DefaultMeleeStrength
#define GetDefaultMeleeWeaponStrength() g_DefaultMeleeStrength
#define SetDefaultMeleeWeaponStrength(%1) g_DefaultMeleeStrength = %1

#define WEAPON_PISTOL "weapon_pistol"
#define NETPROP_WEAPON_CLIP1 "m_iClip1"

#define DEFAULT_MELEE_WEAPON_SCRIPT_NAME "baseball_bat"
#define DATAMAP_MELEE_WEAPON_SCRIPT_NAME "m_strMapSetScriptName"
new Handle:g_MeleeWeaponStrengthTrie
#define GetMeleeWeaponStrengthTrieHandle() g_MeleeWeaponStrengthTrie

#define MELEE_WEAPON_STRENGTH_NOT_SET_VALUE -1
#define MELEE_WEAPON_STRENGTH_UNLIMITED_VALUE -2

#define DEFAULT_MELEE_WEAPON_SOUND_EFFECT SOUND_MELEE_WEAPON_BREAKAGE_WOODEN
new Handle:g_MeleeWeaponSoundEffectTrie
#define GetMeleeWeaponSoundEffectTrieHandle() g_MeleeWeaponSoundEffectTrie

new g_MeleeBreakSoundEffect[MAXENTITIES + 1]
#define GetMeleeWeaponBreakSoundEffectValue(%1) g_MeleeBreakSoundEffect[%1]
#define SetMeleeWeaponBreakSoundEffectValue(%1,%2) g_MeleeBreakSoundEffect[%1] = %2

#define NETPROP_BLOODYWEAPONLEVEL "m_iBloodyWeaponLevel"
#define BLOODYWEAPONLEVEL_LOW 0
#define BLOODYWEAPONLEVEL_MEDIUM 6
#define BLOODYWEAPONLEVEL_HIGH 10

#define CONVAR_BLOODY_STRENGTH_LOW_NAME "breakablemeleeweapons_bloodystrength_low"
#define CONVAR_BLOODY_STRENGTH_LOW_VALUE "0.20"
#define CONVAR_BLOODY_STRENGTH_LOW_DESC "When to apply high blood level on weapon to show low strength left. 0.0 = Disable"
#define CONVAR_BLOODY_STRENGTH_LOW_FLAGS FCVAR_PLUGIN
new Float:g_BloodyStrength_Low
#define GetBloodyStrengthLow() g_BloodyStrength_Low
#define SetBloodyStrengthLow(%1) g_BloodyStrength_Low = %1

#define CONVAR_BLOODY_STRENGTH_MEDIUM_NAME "breakablemeleeweapons_bloodystrength_medium"
#define CONVAR_BLOODY_STRENGTH_MEDIUM_VALUE "0.50"
#define CONVAR_BLOODY_STRENGTH_MEDIUM_DESC "When to apply medium blood level on weapon to show medium strength left. 0.0 = Disable"
#define CONVAR_BLOODY_STRENGTH_MEDIUM_FLAGS FCVAR_PLUGIN
new Float:g_BloodyStrength_Medium
#define GetBloodyStrengthMedium() g_BloodyStrength_Medium
#define SetBloodyStrengthMedium(%1) g_BloodyStrength_Medium = %1

#define COMMAND_SETINFO_NAME "breakablemeleeweapons_setinfo"
#define COMMAND_SETINFO_ADMINFLAGS ADMFLAG_CONVARS
#define COMMAND_SETINFO_DESC "breakablemeleeweapons_setinfo <melee> <strength> <wooden|metal> - Set melee weapon strength and material information"
#define COMMAND_SETINFO_FLAGS FCVAR_PLUGIN

#define TRANSLATION_FILE_BREAKABLEMELEEWEAPONS "breakablemeleeweapons.phrases"
#define TRANSLATION_BREAKAGE_NOTIFY_MESSAGE "Your melee weapon broke apart"

#define CONVAR_NOTIFY_ON_BREKAGE_NAME "breakablemeleeweapons_notify"
#define CONVAR_NOTIFY_ON_BREKAGE_VALUE "0"
#define CONVAR_NOTIFY_ON_BREKAGE_DESC "Whether to notify player when their melee weapons break apart. 0 = Disable, 1 = Chat message, 2 = Hint message"
#define CONVAR_NOTIFY_ON_BREKAGE_FLAGS FCVAR_PLUGIN
new Handle:g_ConVar_NotifyOnBreakage

/* Plugin Functions */
public OnPluginStart()
{
	LoadTranslations(TRANSLATION_FILE_BREAKABLEMELEEWEAPONS)
	
	g_MeleeWeaponStrengthTrie = CreateTrie()
	g_MeleeWeaponSoundEffectTrie = CreateTrie()
	
	new Handle:convar
	
	g_ShouldEmptyPistolConvar = CreateConVar(CONVAR_GIVE_EMPTY_PISTOL_NAME, CONVAR_GIVE_EMPTY_PISTOL_VALUE, CONVAR_GIVE_EMPTY_PISTOL_DESC, CONVAR_GIVE_EMPTY_PISTOL_FLAGS)
	
	convar = CreateConVar(CONVAR_DEFAULT_STRENGTH_NAME, CONVAR_DEFAULT_STRENGTH_VALUE, CONVAR_DEFAULT_STRENGTH_DESC, CONVAR_DEFAULT_STRENGTH_FLAGS)
	HookConVarChange(convar, OnDefaultMeleeStrengthConVarChanged)
	SetDefaultMeleeWeaponStrength(GetConVarInt(convar))
	
	convar = CreateConVar(CONVAR_BLOODY_STRENGTH_LOW_NAME, CONVAR_BLOODY_STRENGTH_LOW_VALUE, CONVAR_BLOODY_STRENGTH_LOW_DESC, CONVAR_BLOODY_STRENGTH_LOW_FLAGS)
	HookConVarChange(convar, OnBloodyStrengthLowConVarChanged)
	SetBloodyStrengthLow(GetConVarFloat(convar))
	
	convar = CreateConVar(CONVAR_BLOODY_STRENGTH_MEDIUM_NAME, CONVAR_BLOODY_STRENGTH_MEDIUM_VALUE, CONVAR_BLOODY_STRENGTH_MEDIUM_DESC, CONVAR_BLOODY_STRENGTH_MEDIUM_FLAGS)
	HookConVarChange(convar, OnBloodyStrengthMediumConVarChanged)
	SetBloodyStrengthMedium(GetConVarFloat(convar))
	
	g_ConVar_NotifyOnBreakage = CreateConVar(CONVAR_NOTIFY_ON_BREKAGE_NAME, CONVAR_NOTIFY_ON_BREKAGE_VALUE, CONVAR_NOTIFY_ON_BREKAGE_DESC, CONVAR_NOTIFY_ON_BREKAGE_FLAGS)
	
	RegAdminCmd(COMMAND_SETINFO_NAME, OnSetInfoCommand, COMMAND_SETINFO_ADMINFLAGS, COMMAND_SETINFO_DESC, _, COMMAND_SETINFO_FLAGS)
	
	HookEvent("player_team", OnPlayerTeam_Event)
}

public OnAllPluginsLoaded()
{
	for (new client = 1; client <= MaxClients; client++) {
		if (!IsClientInGame(client)) {
			continue
		}
		
		SetClientIsInGameCached(client, true)
		SetPlayerIsSurvivor(client, L4DTeam:GetClientTeam(client) == L4DTeam_Survivor)
		SetPlayerIsInfected(client, L4DTeam:GetClientTeam(client) == L4DTeam_Infected)
		SDKHook(client, SDKHook_OnTakeDamagePost, OnTakeDamagePost)
		SDKHook(client, SDKHook_OnTakeDamage, OnTakeDamage)
	}
}

public OnDefaultMeleeStrengthConVarChanged(Handle:convar, const String:oldValue[], const String:newValue[])
{
	SetDefaultMeleeWeaponStrength(GetConVarInt(convar))
}

public OnBloodyStrengthLowConVarChanged(Handle:convar, const String:oldValue[], const String:newValue[])
{
	SetBloodyStrengthLow(GetConVarFloat(convar))
}

public OnBloodyStrengthMediumConVarChanged(Handle:convar, const String:oldValue[], const String:newValue[])
{
	SetBloodyStrengthMedium(GetConVarFloat(convar))
}

public Action:OnSetInfoCommand(client, args)
{
	if (args != 3) {
		ReplyToCommand(client, "[SM] Usage: %s <melee> <strength> <wooden|metal>", COMMAND_SETINFO_NAME)
		return Plugin_Handled
	}
	
	new String:melee[64]
	GetCmdArg(1, melee, sizeof(melee))
	
	decl String:strengthString[32]
	GetCmdArg(2, strengthString, sizeof(strengthString))
	new strength = StringToInt(strengthString)
	
	new soundEffectValue = DEFAULT_MELEE_WEAPON_SOUND_EFFECT
	decl String:material[32]
	GetCmdArg(3, material, sizeof(material))
	if (StrEqual(material, "metal", false))
		soundEffectValue = SOUND_MELEE_WEAPON_BREAKAGE_METAL
	else if (StrEqual(material, "wooden", false))
		soundEffectValue = SOUND_MELEE_WEAPON_BREAKAGE_WOODEN
	
	SetTrieValue(GetMeleeWeaponStrengthTrieHandle(), melee, strength)
	SetTrieValue(GetMeleeWeaponSoundEffectTrieHandle(), melee, soundEffectValue)
	
	ReplyToCommand(client, "[SM] Added \"%s\" with strength of %d and material of \"%s\".", melee, strength,
		(soundEffectValue == SOUND_MELEE_WEAPON_BREAKAGE_METAL ? "metal" : "wooden"))
	
	return Plugin_Handled
}

public OnMapStart()
{
	for (new i = 0; i < sizeof(SOUND_MELEE_WEAPON_BREAKAGE); i++)
		PrecacheSound(SOUND_MELEE_WEAPON_BREAKAGE[i])
	
	SetIsInMapChange(false)
}

public OnMapEnd()
{
	SetIsInMapChange(true)
	
	for (new entity = 1; entity <= MAXENTITIES; entity++) {
		SetMeleeWeaponDurability(entity, MELEE_WEAPON_STRENGTH_NOT_SET_VALUE)
		SetMeleeWeaponMaxDurability(entity, MELEE_WEAPON_STRENGTH_NOT_SET_VALUE)
		SetMeleeWeaponBreakSoundEffectValue(entity, DEFAULT_MELEE_WEAPON_SOUND_EFFECT)
	}
}

public OnClientPutInServer(client)
{
	SetClientIsInGameCached(client, true)
	SDKHook(client, SDKHook_OnTakeDamagePost, OnTakeDamagePost)
	SDKHook(client, SDKHook_OnTakeDamage, OnTakeDamage)
}

public OnClientDisconnect(client)
{
	SetPlayerIsSurvivor(client, false)
	SetClientIsInGameCached(client, false)
}

public OnEntityCreated(entity, const String:classname[])
{
	if (IsInMapChange())
		return
	
	if (StrEqual(classname, CLASSNAME_INFECTED) ||
		StrEqual(classname, CLASSNAME_WITCH) || 
		StrEqual(classname, CLASSNAME_WITCH_BRIDE)) {
		SDKHook(entity, SDKHook_OnTakeDamagePost, OnTakeDamagePost)
	}
}

public OnEntityDestroyed(entity)
{
	if (IsInMapChange())
		return
	
	if (entity > 0 && entity <= MAXENTITIES) {
		SetMeleeWeaponDurability(entity, MELEE_WEAPON_STRENGTH_NOT_SET_VALUE)
		SetMeleeWeaponMaxDurability(entity, MELEE_WEAPON_STRENGTH_NOT_SET_VALUE)
		SetMeleeWeaponBreakSoundEffectValue(entity, DEFAULT_MELEE_WEAPON_SOUND_EFFECT)
	}
}

public OnPlayerTeam_Event(Handle:event, const String:name[], bool:dontBroadcast)
{
	new client = GetClientOfUserId(GetEventInt(event, "userid"))
	if (client <= 0 || client > MaxClients || !IsClientInGameCached(client))
		return
	
	new L4DTeam:team = L4DTeam:GetEventInt(event, "team")
	
	SetPlayerIsSurvivor(client, team == L4DTeam_Survivor)
	SetPlayerIsInfected(client, team == L4DTeam_Infected)
}

/*
 * OnTakeDamage instead of "infected_hurt" and "player_death" is of multiple
 * reasons.
 * 1. Melee weapons that hits the head hitgroup never triggers "infected_hurt"
 * or "player_hurt". Instead it triggers "infected_decapitated", which carries
 * no information regarding the victim or damage dealt.
 * 2. SI have various multipliers on melee weapon damage depending on where
 * the SI gets hit. Head = 4.0, Torso & arms = 1.25, Legs = 0.75. These are 
 * multipliers total health not remaining health unless it is not a killing
 * blow (legs).
 * 3. The Witch is just a mess. "infected_hurt" only triggers on her if 
 * Survivor does not hit her in the head.
 */
public Action:OnTakeDamage(victim, &attacker, &inflictor, &Float:damage, &damagetype)
{
	if (!IsValidSurvivorPlayer(attacker) || victim == attacker || !IsValidInfectedPlayer(victim))
		return Plugin_Continue
	
	if (damage <= 0.0)
		return Plugin_Continue
	
	if (!IsDamageTypeMeleeWeapon(damagetype))
		return Plugin_Continue
	
	new health = GetClientHealth(victim)
	
	if (float(health) > damage)
		SetHealthBeforeMeleeSwing(victim, RoundToFloor(damage))
	else
		SetHealthBeforeMeleeSwing(victim, health)
	
#if DEBUG
	Debug_PrintText("%N health before melee swing: %d", victim, GetHealthBeforeMeleeSwing(victim))
#endif
	return Plugin_Continue
}

public OnTakeDamagePost(victim, attacker, inflictor, Float:damage, damagetype)
{
	if (!IsValidSurvivorPlayer(attacker) || victim == attacker)
		return
	
/*
#if DEBUG
	Debug_PrintText("Damagetype %d %s", damagetype, 
		(damagetype == DAMAGETYPE_MELEE_WEAPON_SHARP ? "(SHARP)" : 
		(damagetype == DAMAGETYPE_MELEE_WEAPON_BLUNT ? "(BLUNT)" : 
		(damagetype == DAMAGETYPE_MELEE_WEAPON_SHARP_DECAPITATION ? "(SHARP, DECAPITATION)" :
		(damagetype == DAMAGETYPE_MELEE_WEAPON_BLUNT_DECAPITATION ? " (BLUNT, DECAPITATION)" :
		"(UNKNOWN)")))))
#endif
*/
	
	if (!IsDamageTypeMeleeWeapon(damagetype))
		return
	
	if (inflictor > 0 && inflictor <= MAXENTITIES && IsValidEntity(inflictor))
		SetBloodLevelOfMeleeWeapon(inflictor)
	
	if (damage <= 0.0)
		return
	
	if (inflictor <= 0 || inflictor > MAXENTITIES || !IsValidEntity(inflictor))
		return
	
	if (IsValidInfectedPlayer(victim))
		damage = float(GetHealthBeforeMeleeSwing(victim))
	
	CalculateMeleeDurability(attacker, inflictor, RoundToFloor(damage))
	SetBloodLevelOfMeleeWeapon(inflictor)
	
#if DEBUG
	Debug_PrintText("BloodyLevel %d", GetEntProp(inflictor, Prop_Send, NETPROP_BLOODYWEAPONLEVEL))
#endif
}

static CalculateMeleeDurability(client, weapon, damage)
{
	if (damage <= 0)
		return
	
	new durability = GetMeleeWeaponDurability(weapon)
	
	if (durability == MELEE_WEAPON_STRENGTH_NOT_SET_VALUE) {
		new String:melee[64] = DEFAULT_MELEE_WEAPON_SCRIPT_NAME
		GetEntPropString(weapon, Prop_Data, DATAMAP_MELEE_WEAPON_SCRIPT_NAME, melee, sizeof(melee))
		
#if DEBUG
		Debug_PrintText("Finding strength for melee weapon \"%s\"...", melee)
#endif
		new strength = GetDefaultMeleeWeaponStrength()
#if DEBUG
		if (GetTrieValue(GetMeleeWeaponStrengthTrieHandle(), melee, strength)) {
			Debug_PrintText("Strength: %d", strength)
		} else {
			Debug_PrintText("Strength: %d (default)", strength)
		}
#else
		GetTrieValue(GetMeleeWeaponStrengthTrieHandle(), melee, strength)
#endif
		new soundEffectValue = DEFAULT_MELEE_WEAPON_SOUND_EFFECT
		GetTrieValue(GetMeleeWeaponSoundEffectTrieHandle(), melee, soundEffectValue)
		SetMeleeWeaponBreakSoundEffectValue(weapon, soundEffectValue)
#if DEBUG
		Debug_PrintText("soundEffectValue %d (%s)", GetMeleeWeaponBreakSoundEffectValue(weapon), SOUND_MELEE_WEAPON_BREAKAGE[GetMeleeWeaponBreakSoundEffectValue(weapon)])
#endif
		
		if (strength > 0) {
			SetMeleeWeaponDurability(weapon, strength)
			SetMeleeWeaponMaxDurability(weapon, strength)
			durability = strength
		} else {
			SetMeleeWeaponDurability(weapon, MELEE_WEAPON_STRENGTH_UNLIMITED_VALUE)
			SetMeleeWeaponMaxDurability(weapon, MELEE_WEAPON_STRENGTH_UNLIMITED_VALUE)
			return
		}
	} else if (durability == MELEE_WEAPON_STRENGTH_UNLIMITED_VALUE) {
		return
	}
	
	durability -= damage
#if DEBUG
	Debug_PrintText("%N with melee %d, damage done %d, remaining durability %d", client, weapon, damage, durability)
#endif
	
	if (durability > 0) {
		SetMeleeWeaponDurability(weapon, durability)
		return
	}
	
	EmitSoundToAll(SOUND_MELEE_WEAPON_BREAKAGE[GetMeleeWeaponBreakSoundEffectValue(weapon)], client)
	SetMeleeWeaponBreakSoundEffectValue(weapon, DEFAULT_MELEE_WEAPON_SOUND_EFFECT)
	
	SetMeleeWeaponDurability(weapon, MELEE_WEAPON_STRENGTH_NOT_SET_VALUE)
	SetMeleeWeaponMaxDurability(weapon, MELEE_WEAPON_STRENGTH_NOT_SET_VALUE)
	L4D_RemoveWeaponSlot(client, L4DWeaponSlot_Secondary)
	
	new pistol = GivePlayerItem(client, WEAPON_PISTOL)
	if (pistol > 0 && IsValidEntity(pistol)) {
		EquipPlayerWeapon(client, pistol)
		if (GetConVarBool(g_ShouldEmptyPistolConvar)) {
			SetEntProp(pistol, Prop_Data, NETPROP_WEAPON_CLIP1, 0)
		}
	}
	
	new notifyStyle = GetConVarInt(g_ConVar_NotifyOnBreakage)
	if (notifyStyle > 0) {
		if (notifyStyle == 1) {
			CPrintToChat(client, "%t", TRANSLATION_BREAKAGE_NOTIFY_MESSAGE)
		} else if (notifyStyle == 2) {
			PrintHintText(client, "%t", TRANSLATION_BREAKAGE_NOTIFY_MESSAGE)
		}
	}
}

static SetBloodLevelOfMeleeWeapon(weapon)
{
	new durability = GetMeleeWeaponDurability(weapon)
	new maxDurability = GetMeleeWeaponMaxDurability(weapon)
	if (durability == MELEE_WEAPON_STRENGTH_NOT_SET_VALUE ||
		durability == MELEE_WEAPON_STRENGTH_UNLIMITED_VALUE ||
		maxDurability == MELEE_WEAPON_STRENGTH_NOT_SET_VALUE ||
		maxDurability == MELEE_WEAPON_STRENGTH_UNLIMITED_VALUE) {
		return
	}
	
	new Float:percentageDurability = float(durability) / float(maxDurability)
	
	new Float:mediumDurability = GetBloodyStrengthMedium()
	new Float:lowDurability = GetBloodyStrengthLow()
	if (mediumDurability <= 0.0 &&
		lowDurability <= 0.0) {
		return
	}
	
	new bloodyLevel = BLOODYWEAPONLEVEL_HIGH
	if (mediumDurability > 0.0 && percentageDurability > mediumDurability)
		bloodyLevel = BLOODYWEAPONLEVEL_LOW
	else if (lowDurability > 0.0 && percentageDurability > lowDurability)
		bloodyLevel = BLOODYWEAPONLEVEL_MEDIUM
	
	SetEntProp(weapon, Prop_Send, NETPROP_BLOODYWEAPONLEVEL, bloodyLevel)
}

stock bool:IsValidSurvivorPlayer(client)
{
	return (client > 0 && client <= MaxClients && IsClientInGameCached(client) && IsPlayerSurvivor(client))
}

stock bool:IsValidInfectedPlayer(client)
{
	return (client > 0 && client <= MaxClients && IsClientInGameCached(client) && IsPlayerInfected(client))
}

#if DEBUG
stock Debug_PrintText(const String:format[], any:...)
{
	decl String:buffer[256]
	VFormat(buffer, sizeof(buffer), format, 2)

	LogMessage(buffer)

	new AdminId:adminId
	for (new client = 1; client <= MaxClients; client++)
	{
		if (!IsClientInGame(client) || IsFakeClient(client))
		{
			continue;
		}

		adminId = GetUserAdmin(client)
		if (adminId == INVALID_ADMIN_ID || !GetAdminFlag(adminId, Admin_Root))
		{
			continue
		}

		PrintToChat(client, "[%s] %s", DEBUG_TAG, buffer)
	}
}
#endif