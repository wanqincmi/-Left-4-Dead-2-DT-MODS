#include <sourcemod>
#include <left4dhooks>

int hp_multiple;
Handle hantime_standup[MAXPLAYERS+1];
ConVar CVsubdued_health;

public Plugin myinfo =
{
    name = "修改被制服后的血量",
    author = "仟姬物语",
    description = "包含倒下和挂边",
    version = "",
    url = "https://space.bilibili.com/10684945"
};

public void OnPluginStart()
{
    CVsubdued_health = CreateConVar("l4d2_incap_subdued_hp", "600",	"被制服后的血量", FCVAR_NOTIFY);
    HookEvent("player_incapacitated",       Event_PlayerIncapacitated);
    HookEvent("player_ledge_grab",          Event_PlayerIncapacitated);
    HookEvent("revive_begin",               Event_ReviveBegin);
    HookEvent("revive_end",                 Event_ReviveEnd);
    AutoExecConfig(true, "l4d2_incap_hp");
}

//玩家被制服时
void Event_PlayerIncapacitated(Event event, const char[] name, bool dontBroadcast)
{
    int client = GetClientOfUserId(GetEventInt(event, "userid"));
    if(IsClientInGame(client) && GetClientTeam(client) == 2)
    {
        hp_multiple = RoundFloat(CVsubdued_health.IntValue / 300.0);
        SetEntProp(client, Prop_Data, "m_iHealth", CVsubdued_health.IntValue);
    }
}

//救人开始时
void Event_ReviveBegin(Event event, const char[] name, bool dontBroadcast)
{
    int rescuer = GetClientOfUserId(GetEventInt(event, "userid"));
    int besaved = GetClientOfUserId(GetEventInt(event, "subject"));
    float adrenaline_time = Terror_GetAdrenalineTime(rescuer);
    float srd = GetConVarFloat(FindConVar("survivor_revive_duration"));
    if(adrenaline_time != -1.0)
        srd /= 2.0;
    
    if(GetEntProp(besaved, Prop_Send, "m_isHangingFromLedge"))
        hantime_standup[besaved] = CreateTimer(srd-0.1, ReductionHP, besaved)
}

Action ReductionHP(Handle Timer, any client)
{
    int Remaining_HP = GetEntProp(client, Prop_Data, "m_iHealth");
    SetEntProp(client, Prop_Data, "m_iHealth", Remaining_HP / hp_multiple);
    return Plugin_Continue;
}

//救人中断时
void Event_ReviveEnd(Event event, const char[] name, bool dontBroadcast)
{
    int client = GetClientOfUserId(GetEventInt(event, "subject"));
    delete hantime_standup[client];
}