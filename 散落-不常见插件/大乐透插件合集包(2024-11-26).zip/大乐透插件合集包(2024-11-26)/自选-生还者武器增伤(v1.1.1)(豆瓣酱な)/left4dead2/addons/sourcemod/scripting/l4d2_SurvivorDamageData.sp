/*
 *	注意:该插件需要配套插件才能运行.
 *	数据库文件位置 *\Left 4 Dead 2\left4dead2\addons\sourcemod\data\sqlite\SurvivorSystem.sq3
 *
 *	v1.0.0
 *
 *	1:初始版本发布.
 *
 *	v1.0.1
 *
 *	1:尝试修复报错问题.
 *
 *	v1.1.1
 *
 *	1:新增近战增伤功能.
 *
 */
#pragma semicolon 1
//強制1.7以後的新語法
#pragma newdecls required
#include <sourcemod>
#include <l4d2_SurvivorDamage>

#define MAX_LENGTH		128		//字符串最大值.

#define PLUGIN_VERSION	"1.1.1"
#define CVAR_FLAGS		FCVAR_NOTIFY

//枪械增伤.
char g_sGunDamage[][][MAX_LENGTH] = 
{
	{"小手枪", 		"pistol", 			"0", "500", "10"},
	{"马格南", 		"pistol_magnum", 	"0", "1200", "15"},
	{"UZI微冲", 	"smg", 				"0", "1800", "15"},
	{"MP5微冲", 	"smg_mp5", 			"0", "1800", "15"},
	{"MAC微冲", 	"smg_silenced", 	"0", "1800", "15"},
	{"单发木喷", 	"pumpshotgun", 		"0", "3500", "20"},
	{"单发铁喷", 	"shotgun_chrome", 	"0", "3500", "20"},
	{"M16步枪", 	"rifle", 			"0", "2800", "25"},
	{"三连发步枪", 	"rifle_desert", 	"0", "3500", "25"},
	{"AK47步枪", 	"rifle_ak47", 		"0", "5500", "25"},
	{"SG552步枪", 	"rifle_sg552", 		"0", "3000", "25"},
	{"一代连喷", 	"autoshotgun", 		"0", "8500", "20"},
	{"二代连喷", 	"shotgun_spas", 	"0", "8500", "20"},
	{"连发木狙", 	"hunting_rifle", 	"0", "3800", "25"},
	{"军用狙击枪", 	"sniper_military", 	"0", "4200", "25"},
	{"单发鸟狙", 	"sniper_scout", 	"0", "15000", "55"},
	{"AWP大狙", 	"sniper_awp", 		"0", "25000", "75"},
	{"M60机枪", 	"rifle_m60",		"0", "6500", "25"},
	{"榴弹发射器", 	"grenade_launcher",	"0", "3500", "0"}//这个功能还没写.
};
//近战增伤.
char g_sMeleeDamage[][][MAX_LENGTH] = 
{
	{"斧头", 		"fireaxe", 			"0", "8000", "25"},
	{"平底锅", 		"frying_pan", 		"0", "8000", "25"},
	{"砍刀", 		"machete", 			"0", "35000", "25"},
	{"棒球棒", 		"baseball_bat", 	"0", "15000", "25"},
	{"撬棍", 		"crowbar", 			"0", "15000", "25"},
	{"球拍", 		"cricket_bat", 		"0", "15000", "25"},
	{"警棍", 		"tonfa", 			"0", "23000", "25"},
	{"武士刀", 		"katana", 			"0", "30000", "25"},
	{"电吉他", 		"electric_guitar", 	"0", "15000", "25"},
	{"小刀", 		"knife", 			"0", "23000", "25"},
	{"高尔夫球棍", 	"golfclub", 		"0", "8000", "25"},
	{"铁铲", 		"shovel", 			"0", "5000", "25"},
	{"草叉", 		"pitchfork", 		"0", "3500", "25"}
};

public Plugin myinfo =  
{
	name = "l4d2_SurvivorDamageData",
	author = "豆瓣酱な",
	description = "设置生还者增伤菜单的配置",
	version = PLUGIN_VERSION,
	url = "N/A"
};
//所有插件加载完成后执行一次(延迟加载插件也会执行一次).
public void OnAllPluginsLoaded()   
{
	IsWeaponDamageLoad();//生还者武器增伤插件加载时.
}
//生还者武器增伤插件加载时.
public void OnWeaponDamageLoad(bool bLateLoad)
{
	IsWeaponDamageLoad();//生还者武器增伤插件加载时.
}
//生还者武器增伤插件加载时.
void IsWeaponDamageLoad()
{
	int value[2];

	//设置枪械增伤配置(不设置则使用默认值).
	GetWeaponDamageNumber(value);
	
	for (int i = 0; i < value[0]; i++)
		for (int y = 0; y < value[1]; y++)
			SetWeaponDamageNumber(i, y, g_sGunDamage[i][y]);

	//设置近战增伤配置(不设置则使用默认值).
	GetMeleeDamageNumber(value);
	
	for (int i = 0; i < value[0]; i++)
		for (int y = 0; y < value[1]; y++)
			SetMeleeDamageNumber(i, y, g_sMeleeDamage[i][y]);
}