/*
 *	注意:该插件需要配套插件才能运行.
 *	数据库文件位置 *\Left 4 Dead 2\left4dead2\addons\sourcemod\data\sqlite\SurvivorSystem.sq3
 *
 *	v1.0.0
 *
 *	1:初始版本发布.
 *
 *	v1.0.1
 *
 *	1:修复射击加速显示异常的问题.
 *
 *	v1.1.1
 *
 *	1:新增购买近战攻速.
 *
 *	v1.1.2
 *
 *	1:修改部分枪械可购买的最大射速上限.
 *	2:修改近战武器可购买的最大攻速上限.
 *
 *	v1.1.3
 *
 *	1:M16和SG552不能设置射速,否则会无声音.
 *	2:M60再次降低射速,否则会无声音.
 *
 *	v1.1.4
 *
 *	1:三连发步枪测试结果是增加射速可能导致声音异常.
 *
 *	v1.2.4
 *
 *	1:新增玩家读取数据库状态的布尔值,已读取数据库值时=true,反之=false.
 *
 *	v1.2.5
 *
 *	1:修复写入大于0的默认值不生效的问题.
 *
 *	v1.3.5
 *
 *	1:新增生还者增强数据成功读取时的转发.
 *
 *	v1.4.5
 *
 *	1:新增自动补充弹药.
 *
 *	v1.4.6
 *
 *	1:开启全部武器自动补充后备弹药变量忘记改成个人的了.
 *
 *	v1.4.7
 *
 *	1:脑抽把这个开启全部主武器自动补充弹药变量每关都重置了.
 *
 *	v1.5.7
 *
 *	1:删除补充弹药的部分,拆分成独立功能.
 *
 *	v1.5.8
 *
 *	1:降低了M60和AK47的射速上限,因为换弹速度升级满了后声音会播放异常.
 *
 *	v1.5.9
 *
 *	1:降低最大上限后超过的部分重新设置为最大值.
 *
 *	v1.5.10
 *
 *	1:修复掉落的警棍无加速的问题.
 *	2:物价持续上涨中.
 *	3:售价新增对齐显示.
 *
 *	v1.5.11
 *
 *	1:修复降低上限后超过的部分忽略失败的问题.
 *
 */
#pragma semicolon 1
//強制1.7以後的新語法
#pragma newdecls required
#include <sourcemod>
#include <l4d2_SurvivorEnhance>

#define MAX_LENGTH		128		//字符串最大值.

#define PLUGIN_VERSION	"1.5.11"
#define CVAR_FLAGS		FCVAR_NOTIFY

//枪械(换弹加速)中文名是菜单显示的名称,第二和第三不要动,第四是写入数据库的默认值,第五是售价,第六是百分比上限,最小值:100(上限过高无意义).
char g_sWeaponReloa[][][] = 
{
	{"小手枪",		"reloa", "pistol", 			"0", "300", "300"},
	{"马格南",		"reloa", "pistol_magnum", 	"0", "450", "300"},
	{"UZI微冲",		"reloa", "smg", 			"0", "600", "220"},
	{"MP5微冲",		"reloa", "smg_mp5", 		"0", "600", "300"},
	{"MAC微冲",		"reloa", "smg_silenced", 	"0", "600", "300"},
	{"单发木喷",	"reloa", "pumpshotgun", 	"0", "1500", "300"},
	{"单发铁喷",	"reloa", "shotgun_chrome", 	"0", "1500", "300"},
	{"M16步枪", 	"reloa","rifle", 			"0", "2300", "300"},
	{"三连发步枪", 	"reloa","rifle_desert",		"0", "2300", "300"},
	{"AK47步枪", 	"reloa","rifle_ak47", 		"0", "2800", "300"},
	{"SG552步枪", 	"reloa","rifle_sg552", 		"0", "2300", "300"},
	{"一代连喷", 	"reloa","autoshotgun", 		"0", "3600", "300"},
	{"二代连喷", 	"reloa","shotgun_spas", 	"0", "3600", "300"},
	{"连发木狙", 	"reloa","hunting_rifle", 	"0", "800", "300"},
	{"军用狙击枪", 	"reloa","sniper_military", 	"0", "1200", "300"},
	{"单发鸟狙", 	"reloa","sniper_scout", 	"0", "8000", "300"},
	{"AWP大狙", 	"reloa","sniper_awp", 		"0", "15000", "300"},
	{"M60机枪", 	"reloa","rifle_m60", 		"0", "35000", "300"},
	{"榴弹发射器", 	"reloa","grenade_launcher", "0", "5000", "300"}
};
//枪械(射击加速)中文名是菜单显示的名称,第二和第三不要动,第四是写入数据库的默认值,第五是售价,第六是百分比上限,最小值:100(部分武器增加射速会导致声音异常).
char g_sWeaponShoot[][][] = 
{
	{"小手枪", 		"shoot", "pistol", 			"0", "300", "125"}, //换弹速度升级满后射速只能这么多,不然会声音播放异常.
	{"马格南", 		"shoot", "pistol_magnum", 	"0", "550", "300"},
	{"UZI微冲", 	"shoot", "smg", 			"0", "100", "100"},//换弹速度升级满后射速只能这么多,不然会声音播放异常.
	{"MP5微冲", 	"shoot", "smg_mp5", 		"0", "100", "100"},//换弹速度升级满后射速只能这么多,不然会声音播放异常.
	{"MAC微冲", 	"shoot", "smg_silenced", 	"0", "100", "100"},//换弹速度升级满后射速只能这么多,不然会声音播放异常.
	{"单发木喷", 	"shoot", "pumpshotgun", 	"0", "1200", "300"},
	{"单发铁喷", 	"shoot", "shotgun_chrome", 	"0", "1200", "300"},
	{"M16步枪", 	"shoot", "rifle", 			"0", "100", "100"},//换弹速度升级满后射速只能这么多,不然会声音播放异常.
	{"三连发步枪", 	"shoot", "rifle_desert", 	"0", "100", "100"},//换弹速度升级满后射速只能这么多,不然会声音播放异常.
	{"AK47步枪", 	"shoot", "rifle_ak47", 		"0", "1800", "115"},//换弹速度升级满后射速只能这么多,不然会声音播放异常.
	{"SG552步枪", 	"shoot", "rifle_sg552", 	"0", "100", "100"},//换弹速度升级满后射速只能这么多,不然会声音播放异常.
	{"一代连喷", 	"shoot", "autoshotgun", 	"0", "3500", "200"},
	{"二代连喷", 	"shoot", "shotgun_spas", 	"0", "3500", "200"},
	{"连发木狙", 	"shoot", "hunting_rifle", 	"0", "800", "300"},
	{"军用狙击枪", 	"shoot", "sniper_military", "0", "1200", "300"},
	{"单发鸟狙", 	"shoot", "sniper_scout", 	"0", "5500", "280"},
	{"AWP大狙", 	"shoot", "sniper_awp", 		"0", "8500", "300"},
	{"M60机枪", 	"shoot", "rifle_m60", 		"0", "100", "100"}, //换弹速度升级满后射速只能这么多,不然会声音播放异常.
	{"榴弹发射器", 	"shoot", "grenade_launcher", "0", "100", "100"}
};
//近战(攻击加速)中文名是菜单显示的名称,第二和第三不要动,第四是写入数据库的默认值,第五是售价,第六是百分比上限,最小值:100(上限过高会丢失伤害).
char g_sWeaponMelee[][][] = 
{
	{"斧头", 		"speed", "fireaxe", 		"0", "2200", "190"},
	{"平底锅", 		"speed", "frying_pan", 		"0", "1800", "190"},
	{"砍刀", 		"speed", "machete", 		"0", "3000", "190"},
	{"棒球棒", 		"speed", "baseball_bat", 	"0", "2200", "190"},
	{"撬棍", 		"speed", "crowbar", 		"0", "2200", "190"},
	{"球拍", 		"speed", "cricket_bat", 	"0", "2200", "190"},
	{"警棍", 		"speed", "tonfa", 			"0", "2200", "190"},
	{"武士刀", 		"speed", "katana", 			"0", "2200", "190"},
	{"电吉他", 		"speed", "electric_guitar", "0", "2200", "190"},
	{"小刀", 		"speed", "knife", 			"0", "2500", "190"},
	{"高尔夫球棍", 	"speed", "golfclub", 		"0", "2200", "190"},
	{"铁铲", 		"speed", "shovel", 			"0", "1500", "190"},
	{"草叉", 		"speed", "pitchfork", 		"0", "1200", "190"}
};

public Plugin myinfo =  
{
	name = "l4d2_points_survivor",
	author = "豆瓣酱な",
	description = "设置生还者增强菜单的配置",
	version = PLUGIN_VERSION,
	url = "N/A"
};
//所有插件加载完成后执行一次(延迟加载插件也会执行一次).
public void OnAllPluginsLoaded()   
{
	IsWeaponSystemLoad();//生还者武器增强插件加载时.
}
//生还者武器增强插件加载时.
public void OnWeaponSystemLoad(bool bLateLoad)
{
	IsWeaponSystemLoad();//生还者武器增强插件加载时.
}
//生还者武器增强插件加载时.
void IsWeaponSystemLoad()
{
	int value[2];

	//设置换弹加速配置(不设置则使用默认值).
	GetWeaponReloaNumber(value);
	
	for (int i = 0; i < value[0]; i++)
		for (int y = 0; y < value[1]; y++)
			SetWeaponReloaNumber(i, y, g_sWeaponReloa[i][y]);

	//设置射击加速配置(不设置则使用默认值).
	GetWeaponShootNumber(value);
	
	for (int i = 0; i < value[0]; i++)
		for (int y = 0; y < value[1]; y++)
			SetWeaponShootNumber(i, y, g_sWeaponShoot[i][y]);

	//设置近战加速配置(不设置则使用默认值).
	GetWeaponMeleeNumber(value);
	
	for (int i = 0; i < value[0]; i++)
		for (int y = 0; y < value[1]; y++)
			SetWeaponMeleeNumber(i, y, g_sWeaponMelee[i][y]);
}