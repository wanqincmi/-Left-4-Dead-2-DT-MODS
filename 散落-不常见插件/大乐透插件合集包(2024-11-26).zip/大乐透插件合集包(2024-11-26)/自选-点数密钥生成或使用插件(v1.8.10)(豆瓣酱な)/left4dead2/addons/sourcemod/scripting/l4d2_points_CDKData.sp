/*
 *	v1.0.0
 *
 *	1:初始版本发布.
 *
 *	v1.0.1
 *
 *	1:修复不区分大小写的bool写错位置导致的无效.
 *
 *	v1.0.2
 *
 *	1:聊天窗监听写错数字.
 *
 *	v1.0.3
 *
 *	1:使用CDK指令也隐藏.
 *	2:新增设置使用添加CDK指令时的默认点数.
 *
 *	v1.1.3
 *
 *	1:修复可以创建负数CDK的问题.
 *	2:更改为扣除同等数量的点数创建CDK.
 *	3:更改为全部玩家可用创建CDK或只限管理员使用或只限指定的玩家使用.
 *	4:使用CDK指令sm_usecdk.
 *	5:创建CDK指令为sm_addcdk或加上可选参数,指定数量的点数,设置有效期(单位/秒).
 *	示例:sm_addcdk 300 120
 *	说明:其中300表示设置的点数(不设置则使用默认值),120为CDK有效期(不设置或设置0表示永久有效).
 *
 *	v1.2.3
 *
 *	1:新增查询自己的CDK密钥功能.
 *	2:新增给指定玩家创建新密钥.
 *
 *	v1.2.4
 *
 *	1:监听CDK密钥使用命令改成不区分大小写.
 *
 *	v1.2.5
 *
 *	1:新增一个查看密钥用法的选项.
 *
 *	v1.2.6
 *
 *	1:修复IsCreatePlayerCdk函数判断ID获取成功与否的条件写反导致创建密钥失败.
 *	2:新增创建密钥时选择是否扣除当前玩家对应数量的点数.
 *
 *	v1.2.7
 *
 *	1:已使用的密钥保留点数用于显示.
 *
 *	v1.3.7
 *
 *	1:密钥菜单里的点数数量使用对齐显示.
 *
 *	v1.4.7
 *
 *	1:修复密钥可以重复使用的问题.
 *	2:修复未使用的密钥查询条件错误的问题.
 *	3:新增创建者名称,使用者名称和SteamID.
 *	4:该版本数据库表变化了,需要删除旧数据库文件.
 *	5:数据库文件路径(*\left4dead2\addons\sourcemod\data\sqlite\PointsCDK.sq3),如果有的话.
 *
 *	v1.5.7
 *
 *	1:密钥新增小写字母和数字.
 *
 *	v1.5.8
 *
 *	1:差点忘记聊天窗命令还能!sm_的方式使用,这个也加上,防止密钥显示到聊天窗.
 *
 *	v1.5.9
 *
 *	1:密钥里的单引号'自动转义为双引号.
 *
 *	v1.6.9
 *
 *	1:密钥菜单新增直接使用密钥功能.
 *
 *	v1.6.10
 *
 *	1:修改密钥使用方法提示内容.
 *
 *	v1.7.10
 *
 *	1:新增服管给予密钥功能.
 *	2:int里少加了一个可选函数.
 *
 *	v1.8.10
 *
 *	1:删除中奖号码多少才创建密钥改成固定值多少或以上时创建密钥发放点数(开关自动使用在 l4d2_LottoLibrariesData.sp 里修改,默认1开启).
 *	2:设置大乐透中奖多少或以上时创建密钥发放(最小值在 l4d2_LottoLibrariesData.sp 里修改,默认500点数).
 *
 */
#pragma semicolon 1
//強制1.7以後的新語法
#pragma newdecls required
#include <sourcemod>
#include <l4d2_points_CDK>

#define MAX_LENGTH		128		//字符串最大值.

#define PLUGIN_VERSION	"1.8.10"
#define CVAR_FLAGS		FCVAR_NOTIFY

#define ADD_NUMBER			300	//使用添加CDK指令默认点数.
#define CDK_NUMBER			4	//每个CDK总共有多少组字母.
#define CDK_LENGTH			5	//每组CDK有多少个大写字母.
#define STEAM_ID			"STEAM_1:1:000000000"	//设置指定玩家可用sm_addcdk指令.
#define STEAM_ADMIN			"STEAM_1:1:000000000"	//设置服管(可使用给予玩家密钥权限),留空或默认值=禁用(可设置多个用;号隔开).

//设置密钥随机到的类型概率.
char g_sProbability[][][] = 
{
	{"大写字母", "100"},//请至少保留一个字母类型.
	{"小写字母", "30"},
	{"整数数字", "15"}//整数为(0-9).
};

public Plugin myinfo =  
{
	name = "l4d2_points_CDK",
	author = "豆瓣酱な",
	description = "设置CDK插件的配置",
	version = PLUGIN_VERSION,
	url = "N/A"
};
//所有插件加载完成后执行一次(延迟加载插件也会执行一次).
public void OnAllPluginsLoaded()   
{
	IsPointsCdkLoad();//设置CDK插件配置.
}
//CDK插件插件加载时.
public void OnPointsCDKLoad(bool bLateLoad)
{
	IsPointsCdkLoad();//CDK插件插件加载时.
}
void IsPointsCdkLoad()
{
	char sDefault[MAX_LENGTH];
	GetIdDefaultValue(sDefault);//获取默认值.
	SetAddPointsNumber(ADD_NUMBER);
	SetPointsCdkNumber(CDK_NUMBER);
	SetPointsCdkLength(CDK_LENGTH);
	SetAddCdkCommandUser(sDefault);//设置指定玩家可用sm_addcdk指令,设置为空=所有玩家,默认值=管理员.
	SetGivingUserPurview(sDefault);//设置服管(可使用给予玩家密钥权限),留空或默认值=禁用(可设置多个用;号隔开).

	int value[2];

	//设置密钥类型的概率配置(不设置则使用默认值).
	GetProbability(value);
	
	for (int i = 0; i < value[0]; i++)
		for (int y = 0; y < value[1]; y++)
			SetProbability(i, y, g_sProbability[i][y]);
}