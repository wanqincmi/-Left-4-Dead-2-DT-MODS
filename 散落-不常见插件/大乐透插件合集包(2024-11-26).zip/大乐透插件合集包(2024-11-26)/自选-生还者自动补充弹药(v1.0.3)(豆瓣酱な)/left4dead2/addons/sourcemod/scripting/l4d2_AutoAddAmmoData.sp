/*
 *
 *	v1.0.0
 *
 *	1:初始版本发布.
 *
 *	v1.0.1
 *
 *	1:配置文件函数名忘记改.
 *	2:主武器宏定义忘记更换.
 *
 *	v1.0.2
 *
 *	1:补充弹药提示更改为转发,需要自动补充弹药提示的解开注释即可.
 *	2:include里的数据库读取状态的API名称忘记更改.
 *
 *	v1.0.3
 *
 *	1:单独处理M60和榴弹补充后备弹药.
 *
 */
#pragma semicolon 1
//強制1.7以後的新語法
#pragma newdecls required
#include <sourcemod>
#include <l4d2_AutoAddAmmo>

#define MAX_LENGTH		128		//字符串最大值.

#define PLUGIN_VERSION	"1.0.3"
#define CVAR_FLAGS		FCVAR_NOTIFY

//主武器(自动补充弹药)中文名是菜单显示的名称,第二个不要动,第三个是写入数据库的默认值(0=关闭,1=开启),第四个是售价.
char g_sWeaponMain[][][] = 
{
	{"全部主武器", "all_weapon", "0", "15"},
	{"微型冲锋枪", "weapon_smg", "0", "15"},
	{"MP5冲锋枪", "weapon_smg_mp5", "0", "15"},
	{"消音冲锋枪", "weapon_smg_silenced", "0", "15"},
	{"单发木喷", "weapon_pumpshotgun", "0", "25"},
	{"单发铁喷", "weapon_shotgun_chrome", "0", "25"},
	{"M16步枪", "weapon_rifle", "0", "35"},
	{"三连发步枪", "weapon_rifle_desert", "0", "45"},
	{"AK47步枪", "weapon_rifle_ak47", "0", "50"},
	{"SG552步枪", "weapon_rifle_sg552", "0", "45"},
	{"一代连喷", "weapon_autoshotgun", "0", "35"},
	{"二代连喷", "weapon_shotgun_spas", "0", "35"},
	{"连发木狙", "weapon_hunting_rifle", "0", "45"},
	{"军用狙击枪", "weapon_sniper_military", "0", "45"},
	{"单发鸟狙", "weapon_sniper_scout", "0", "55"},
	{"AWP大狙", "weapon_sniper_awp", "0", "65"},
	{"M60机关枪", "weapon_rifle_m60", "0", "95"},
	{"榴弹发射器", "weapon_grenade_launcher", "0", "75"}
};

public Plugin myinfo =  
{
	name = "l4d2_AutoAddAmmoData",
	author = "豆瓣酱な",
	description = "设置生还者弹药菜单的配置",
	version = PLUGIN_VERSION,
	url = "N/A"
};
//所有插件加载完成后执行一次(延迟加载插件也会执行一次).
public void OnAllPluginsLoaded()   
{
	IsWeaponAmmoLoad();//设置生还者弹药插件配置.
}
//生还者弹药插件加载时.
public void OnWeaponAmmoLoad(bool bLateLoad)
{
	IsWeaponAmmoLoad();//生还者弹药插件加载时.
}
void IsWeaponAmmoLoad()
{
	int value[2];

	//设置自动补充弹药配置(不设置则使用默认值).
	GetWeaponMainNumber(value);
	
	for (int i = 0; i < value[0]; i++)
		for (int y = 0; y < value[1]; y++)
			SetWeaponMainNumber(i, y, g_sWeaponMain[i][y]);
}
//自动补充弹药时.
public void OnIsRefillAmmo(int client, int outlay, int points, bool type)
{
	if(type)
	{
		//PrintToChat(client, "\x04[提示]\x05已自动使用\x03%d\x05点数补满弹药,剩余\x03%d\x05点数.", outlay, points);
	}
	else
	{
		//PrintToChat(client, "\x04[提示]\x05不足\x03%d\x05点数,剩余\x03%d\x05点数,自动补充弹药失败.", outlay, points);
	}
}