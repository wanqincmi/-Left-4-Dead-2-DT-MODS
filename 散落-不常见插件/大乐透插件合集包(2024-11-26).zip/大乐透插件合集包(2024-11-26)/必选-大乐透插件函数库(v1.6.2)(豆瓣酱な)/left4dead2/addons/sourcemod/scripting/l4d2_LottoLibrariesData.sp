/*
 *	v1.0.1
 *	1:增加一个购买号码后开奖前玩家离开forward,用于返还购买消耗的积分.
 *
 *	v1.0.2
 *	1:为防止出现问题,在 OnClientPutInServer 和 OnMapStart 里重置下变量.
 *	2:函数 native OpenBigLottoMenu 不是bool类型,更改为void类型.
 *
 *	v1.1.3
 *	1:增加 native GetLotteryNumber	函数,用于获取开奖号码.
 *	2:增加 native GetOrganizeNumber	函数,用于开奖号码和用户号码对齐显示.
 *	3:修复 forward OnLotteryNumber	函数里的获取玩家号码错误.
 *	
 *	v1.2.1
 *	1:修复一些奇奇怪怪的玄学问题.
 *	2:增加 native GetNumberQuantity 用于获取中奖号码的数量.
 *	
 *	v1.3.0
 *	1:增加 native GetNextDrawTime 		用于获取获取下次开奖的时间.
 *	2:增加 native GetRemainingDrawTime 	用于获取开奖剩余的时间.
 *	3:增加 native GetFormatTime 		新增格式化整数为日期.
 *	4:增加 forward ForwardDrawTime 		转发开奖剩余时间.
 *	5:调整了部分API(我也不知道那些调整了).
 *	6:删除自带的开奖时弹出菜单.
 *	7:修复开奖时未购买号码的玩家不会执行转发函数.
 *
 *	v1.4.0
 *	1:增加 native GetMinPoints 			获取购买号码的最小积分数量.
 *	2:增加 native GetMaxPoints 			获取购买号码的最大积分数量.
 *	3:增加 native GetMinWinning 		获取中奖所需的最小号码数量.
 *	5:增加 native GetCalculationValue 	获取左移运算后的值.
 *
 *	v1.4.1
 *	1:插件被卸载时删除创建的全局转发句柄(不清楚偶尔的报错是不是因为这个).
 *
 *	v1.4.2
 *	1:开奖修改为下一帧执行(改成这样后好像没有插件地址无效的报错了).
 *
 *	v1.5.2
 *
 *	1:新增中奖号码多少或以上时使用密钥发放中奖的点数.
 *
 *	v1.6.2
 *
 *	1:删除中奖号码多少或以上时使用密钥发放点数.
 *	2:更改为固定值或以上时.
 *	3:更改为中奖后可自动使用密钥.
 *	
 */
#pragma semicolon 1
//強制1.7以後的新語法
#pragma newdecls required
#include <sourcemod>
#include <l4d2_LottoLibraries>

#define PLUGIN_VERSION	"1.6.2"

//这里的变量更改后最好重开游戏,否则可能导致某些地方显示错误.
#define MAX_POINTS		500		//设置中奖点数大于此值时创建密钥发放.
#define MAX_NUMBER		35		//设置随机值的最大范围(1-?).
#define MAX_WINNING		7		//设置随机的最大号码数量(必须大于中奖的最少号码数量).
#define AUTO_USE_KEY	1		//设置大乐透中奖后自动使用密钥(0=禁用,1=启用).
#define MIN_WINNING		2		//设置获得奖励的最少数量(不能大于随机的最大号码数量).
#define BASE_VALUE		15		//设置奖励的基础值(值越大中奖的号码数量越多奖励越多)(最小值:15).
#define TAX_RATES		0.5		//设置实际收入比例(平衡中奖的收入).

public Plugin myinfo =  
{
	name = "l4d2_LottoLibrariesData",
	author = "豆瓣酱な",
	description = "设置大乐透函数库插件的配置",
	version = PLUGIN_VERSION,
	url = "N/A"
};
//所有插件加载完成后执行一次(延迟加载插件也会执行一次).
public void OnAllPluginsLoaded()   
{
	IsBigLateLoad();//设置乐透依赖插件配置.
}
//乐透依赖插件加载时.
public void OnLottoLibrariesLoad(bool bLateLoad)
{
	IsBigLateLoad();//乐透依赖插件加载时.
}
void IsBigLateLoad()
{
	//设置基础配置(不设置则使用默认值).
	SetMaxKeyPoints(MAX_POINTS);//设置使用密钥发放点数的值.
	SetRandomRange(MAX_NUMBER);//设置随机值的最大范围.
	SetMaxIntNumber(MAX_WINNING);//设置随机的最大号码数量.
	SetAutoUseKey(AUTO_USE_KEY);//设置自动使用密钥开关状态.
	SetMinIntNumber(MIN_WINNING);//设置随机的最小号码数量.
	SetBaseValue(BASE_VALUE);//设置奖励的基础值.
	SetPointsTaxRates(TAX_RATES);//设置收入税收比例.
}