/*
 *	v1.0.0
 *
 *	1:初始版本发布.
 *
 *	v1.0.1
 *
 *	1:修复中途加载插件时不能自动升级激光的问题.
 *
 */
#pragma semicolon 1
//強制1.7以後的新語法
#pragma newdecls required
#include <sourcemod>
#include <l4d2_AutoAddLaser>

#define MAX_LENGTH		128		//字符串最大值.

#define PLUGIN_VERSION	"1.0.1"
#define CVAR_FLAGS		FCVAR_NOTIFY

//主武器(自动升级激光)中文名是菜单显示的名称,第二个不要动,第三个是写入数据库的默认值(0=关闭,1=开启),第四个是售价.
char g_sWeaponLaser[][][] = 
{
	{"全部主武器", "all_weapon", "0", "25"},
	{"微型冲锋枪", "weapon_smg", "0", "25"},
	{"MP5冲锋枪", "weapon_smg_mp5", "0", "25"},
	{"消音冲锋枪", "weapon_smg_silenced", "0", "25"},
	{"单发木喷", "weapon_pumpshotgun", "0", "25"},
	{"单发铁喷", "weapon_shotgun_chrome", "0", "25"},
	{"M16步枪", "weapon_rifle", "0", "25"},
	{"三连发步枪", "weapon_rifle_desert", "0", "25"},
	{"AK47步枪", "weapon_rifle_ak47", "0", "25"},
	{"SG552步枪", "weapon_rifle_sg552", "0", "25"},
	{"一代连喷", "weapon_autoshotgun", "0", "25"},
	{"二代连喷", "weapon_shotgun_spas", "0", "25"},
	{"连发木狙", "weapon_hunting_rifle", "0", "25"},
	{"军用狙击枪", "weapon_sniper_military", "0", "25"},
	{"单发鸟狙", "weapon_sniper_scout", "0", "25"},
	{"AWP大狙", "weapon_sniper_awp", "0", "25"},
	{"M60机关枪", "weapon_rifle_m60", "0", "25"},
	{"榴弹发射器", "weapon_grenade_launcher", "0", "25"}
};

public Plugin myinfo =  
{
	name = "l4d2_AutoAddLaserData",
	author = "豆瓣酱な",
	description = "设置生还者激光菜单的配置",
	version = PLUGIN_VERSION,
	url = "N/A"
};
//所有插件加载完成后执行一次(延迟加载插件也会执行一次).
public void OnAllPluginsLoaded()   
{
	IsWeaponLaserLoad();//设置生还者激光插件配置.
}
//生还者激光插件加载时.
public void OnWeaponLaserLoad(bool bLateLoad)
{
	IsWeaponLaserLoad();//生还者激光插件加载时.
}
void IsWeaponLaserLoad()
{
	int value[2];

	//设置自动升级激光配置(不设置则使用默认值).
	GetWeaponLaserNumber(value);
	
	for (int i = 0; i < value[0]; i++)
		for (int y = 0; y < value[1]; y++)
			SetWeaponLaserNumber(i, y, g_sWeaponLaser[i][y]);
}
//自动升级激光时.
public void OnIsRefillLaser(int client, int outlay, int points, bool type)
{
	if(type)
	{
		//PrintToChat(client, "\x04[提示]\x05已自动使用\x03%d\x05点数升级激光,剩余\x03%d\x05点数.", outlay, points);
	}
	else
	{
		//PrintToChat(client, "\x04[提示]\x05不足\x03%d\x05点数,剩余\x03%d\x05点数,自动升级激光失败.", outlay, points);
	}
}