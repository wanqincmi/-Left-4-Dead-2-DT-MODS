/*
 * v1.1.0
 *	
 *	1:当前钞票总数量或实体总数量超过设定值时不会刷出钞票.
 *
 * v1.2.0
 *	
 *	1:随机钞票颜色.
 *
 * v1.3.0
 *	
 *	1:新增Native和Forwards用于设置插件配置.
 *
 * v1.4.0
 *	
 *	1:新增拾取钞票时随机获得点数.
 *
 * v1.5.0
 *	
 *	1:新增丢失点数功能.
 *	2:此版本必须跟开奖插件一起使用.
 *
 * v1.6.0
 *	
 *	1:新增丢弃钞票的Forward转发.
 *	2:删除设置最低点数的设置函数(好像有兼容性问题).
 *	3:生还者死亡掉落和丢弃的钞票生还者拾取时会显示谁丢弃或掉落的.
 *
 * v1.7.0
 *	
 *	1:恢复设置最低点数的设置函数.
 *	2:取消设置份数,改成自动计算并随机.
 *	3:增加最低点数会直接*总点数,自动计算.
 *
 * v1.7.1
 *	
 *	1:丢弃点数和份数添加对齐显示.
 *
 * v1.7.2
 *	
 *	1:想方设法把最大份数减少了一些.
 *
 * v1.7.3
 *	
 *	1:重新更换了计算份数的方法.
 *
 * v1.7.4
 *	
 *	1:想不到吧,我又调整了下计算份数的方法.
 *	2:丢弃点数删除了自定义份数,改为随机份数.
 *
 * v1.7.5
 *	
 *	1:修复闲置玩家对应的生还者电脑死亡掉落的钞票拾取时名字显示不对的问题.
 *
 * v1.7.6
 *	
 *	1:修复每个钞票获得的最低点数小于最小值的问题.
 *
 * v1.7.7
 *	
 *	1:修复点数不足的情况下还能继续丢钱的BUG.
 *
 * v1.8.7
 *	
 *	1:新增玩家死亡的转发.
 *
 * v1.8.8
 *	
 *	1:更改玩家死亡的转发函数名(因为发现跟其它插件重复了).
 *
 * v1.9.8
 *	
 *	1:新增玩家成功拾取钞票的转发(forward void OnPlayerPickupMoney).
 *	2:成功拾取钞票的提示改到转发里设置.
 *	3:丢弃钞票的转发名称更改为(forward void OnPlayerDropItMoney)
 *
 * v1.10.9
 *	
 *	1:配置文件里的玩家死亡转发函数忘记更改导致提示不显示.
 *	2:新增根据生还者数量和游戏难度增加实际点数.
 *	3:计算方法(根据生还者数量和游戏难度计算实际点数数量).
 *	
 * 	if(生还者数量 <= 4)
 *		最终点数 = RoundToFloor(生还者数量 * 倍数);
 *	else
 *		最终点数 = RoundToFloor(((生还者数量 - 4) * (总点数 / 4) + 总点数) * 倍数);
 *
 * v1.10.10
 *	
 *	1:难度数组里的中文名写错,配置文件里的击杀掉落提示默认注释,只保留生还者死亡.
 *
 * v1.10.11
 *	
 *	1:新增一个API用于解决使用强迫玩家自杀函数无法触发玩家死亡掉落点数的问题.
 *	2:降低了生还者死亡掉落的点数数量.
 *
 * v1.10.12
 *	
 *	1:掉落钞票配置插件里的玩家丢弃点数转发忘记更新.
 *
 * v1.10.13
 *	
 *	1:修复玩家死亡掉落钞票提示显示不正常的问题.
 *	2:删除插件里的丢弃钞票提示,改到配置文件里显示.
 *
 * v1.10.14
 *	
 *	1:修复玩家丢弃钞票转发少写了一个变量导致编译配置文件失败.
 *
 * v1.11.15
 *	
 *	1:喜报,生还者死亡或自杀时掉落点数不会贷款了.
 *	2:增加根据每个章节的死亡次数累计增加额外掉落比例.
 *	3:修复使用 SuicideFallPoints 生还者自杀函数不能根据生还者数量额外增加掉落数量的问题.
 *
 * v1.11.16
 *	
 *	1:修复团灭重开后生还者死亡次数统计少一次的问题.
 *	2:修复玩家丢弃钞票的删除时间设置成了生还者死亡的时间.
 *
 * v1.11.17
 *	
 *	1:修复感染者死亡时会显示掉落0点数0份的问题.
 *
 * v1.12.18
 *	
 *	1:更改创建钞票的方法为每帧创建指定数量,一次创建太多钞票时可以适当减少卡顿感.
 *	2:修复救援离开时钞票过多倒是救援车辆卡成PPT的情况.
 *
 * v1.12.19
 *	
 *	1:新增救援车辆到了时禁用掉落钞票.
 *	2:新增救援准备就绪时删除所有钞票.
 *	3:新增救援车辆离开时删除所有钞票.
 *	4:修复删除丢弃钞票的时间设置错误.
 *	5:感谢鹅佬提供的两个子父实体的互查属性.
 *
 * v1.12.20
 *	
 *	1:修复API接入的函数少填了坐标导致的位置错误和插件报错问题.
 *	2:修复掉落的点数总数量因为不明原因数据丢失导致实际总点数变少的问题.
 *	3:更改上个版本的方法为救援车辆到了,准备就绪,车辆离开,玩家过关,回合结束时删除钞票实体.
 *
 */
#pragma semicolon 1
//強制1.7以後的新語法
#pragma newdecls required
#include <sourcemod>
#include <l4d2_DropMoney>

#define MAX_LENGTH		128		//字符串最大值.

#define PLUGIN_VERSION	"1.12.20"
#define CVAR_FLAGS		FCVAR_NOTIFY

//掉落钞票插件的配置.
#define MAX_ENTITY_NUMBER		1900	//设置最大实体数量上限(最多:2048).
#define USE_MONEY_TIME			1.0		//设置拾取所需的时间/秒(不建议低于1.0秒).
#define PLAYER_REMOVE_MONEY		75.0	//设置玩家丢弃的钞票的删除时间/秒.
#define SURVIVOR_REMOVE_MONEY	65.0	//设置生还者掉落钞票的删除时间/秒.
#define INFECTED_REMOVE_MONEY	45.0	//设置感染者掉落钞票的删除时间/秒.
#define EXTRA_DROP_RATIO		0.15	//设置生还者每次死亡额外掉落比例(累加).
#define MAX_MONEY_NUMBER		250		//设置钞票存在的最大数量.
#define MAX_BRIGHT_RANGE		800		//设置钞票的最大发光距离.
#define MIN_POINTS_VALUE		3		//设置每个钞票获得的最小点数(该值相当于总点数倍数).
#define MAX_POINTS_VALUE		15		//设置每个钞票获得的最大点数(钞票能获得的最大点数).
#define MAX_FRAME_NUMBER		3		//设置每帧最大创建多少个钞票.
#define MAX_ONCE_NUMBER			125		//设置每次掉落的最大钞票数量.

//设置不同难度最终点数倍数.
//if(生还者数量 <= 4)
	//最终点数 = RoundToFloor(生还者数量 * 倍数);
//else
	//最终点数 = RoundToFloor(((生还者数量 - 4) * (总点数 / 4) + 总点数) * 倍数);
char g_sGameDifficultye[][][] = 
{
	{"简单", "Easy", "0.75"},
	{"普通", "Normal", "1.0"},
	{"高级", "Hard", "1.5"},
	{"专家", "Impossible", "2.0"}
};
//生还者死亡掉落钞票(总点数:最小和最大).
int g_iSurvivorName[] = {1, 10};
//感染者死亡掉落钞票的概率().
char g_sZombieName[][][] = 
{
	//(概率:击杀和爆头)(总点数:最小和最大)
	{"舌头", "15", "25", "2", "3"},
	{"胖子", "10", "20", "2", "3"},
	{"猎人", "15", "35", "2", "4"},
	{"口水", "15", "20", "2", "3"},
	{"猴子", "15", "30", "2", "4"},
	{"牛牛", "25", "45", "5", "8"},
	{"女巫", "55", "65", "15", "45"},
	{"坦克", "100", "100", "55", "115"}
};

public Plugin myinfo =  
{
	name = "l4d2_points_info",
	author = "豆瓣酱な",
	description = "设置掉落钞票插件的配置",
	version = PLUGIN_VERSION,
	url = "N/A"
};
//所有插件加载完成后执行一次(延迟加载插件也会执行一次).
public void OnAllPluginsLoaded()   
{
	IsBanknotesFall();//设置掉落钞票插件配置.
}
//掉落钞票插件加载时.
public void OnPointsFallLoad(bool bLateLoad)
{
	IsBanknotesFall();//掉落钞票插件加载时.
}
//掉落钞票插件加载时.
void IsBanknotesFall()
{
	//设置生还者死亡掉落的钞票数量(不设置则使用默认值).
	for (int i = 0; i < GetSurvivorFall(); i++)
		SetSurvivorFall(i, g_iSurvivorName[i]);

	int value[2];
	
	GetInfectedFall(value);
	//设置感染者死亡掉落钞票的概率和数量.
	for (int i = 0; i < value[0]; i++)
		for (int y = 0; y < value[1]; y++)
			SetInfectedFall(i, y, g_sZombieName[i][y]);

	GetActualPoints(value);
	//设置感染者死亡掉落钞票的概率和数量.
	for (int i = 0; i < value[0]; i++)
		for (int y = 0; y < value[1]; y++)
			SetActualPoints(i, y, g_sGameDifficultye[i][y]);

	SetUseMoneyTime(USE_MONEY_TIME);//设置拾取时间.
	SetMaxEntityNumber(MAX_ENTITY_NUMBER);//最大实体数量(最多:2048).
	SetMaxBrightRange(MAX_BRIGHT_RANGE);//设置钞票的最大发光距离.
	SetMaxMoneyNumber(MAX_MONEY_NUMBER);//设置钞票存在的最大数量.
	SetPlayerRemoveMoney(PLAYER_REMOVE_MONEY);//设置玩家丢弃的钞票的删除时间/秒.
	SetSurvivorRemoveMoney(SURVIVOR_REMOVE_MONEY);//设置生还者掉落钞票的删除时间/秒.
	SetInfectedRemoveMoney(INFECTED_REMOVE_MONEY);//设置感染者掉落钞票的删除时间/秒.
	SetMinPointsValue(MIN_POINTS_VALUE);//设置每个钞票获得的最小点数.
	SetMaxPointsValue(MAX_POINTS_VALUE);//设置每个钞票获得的最大点数.
	SetExtraDropRatio(EXTRA_DROP_RATIO);//设置生还者每次死亡额外增加的掉落比例.
	SetMaxFrameNumber(MAX_FRAME_NUMBER);//设置每帧创建的最大钞票数量.
	SetMaxOnceNumber(MAX_ONCE_NUMBER);//设置每次掉落的最大钞票数量.
}
//玩家成功拾取钞票时.
public void OnPlayerPickupMoney(int client, int number, int total)
{
	PrintToChat(client, "\x04[提示]\x05获得了\x03%d\x05点数\x04,\x05总共\x03%d\x05点数\x04.", number, total);
}
//玩家死亡时.
public void OnPlayerDeathFall(int victim, int total, int number, int remaining)
{
	if (IsValidEdict(victim))
	{
		char classname[32];
		GetEdictClassname(victim, classname, sizeof(classname));
		if (strcmp(classname, "witch") == 0)
		{
			for (int i = 1; i <= MaxClients; i++)
				if (IsClientInGame(i) && GetClientTeam(i) == 2 && !IsFakeClient(i))
				{
					PrintToChat(i, "\x04[提示]\x05感染者\x03%s\x05掉落\x03%d\x05点数\x04,\x05共\x03%d\x05份\x04.", g_sZombieName[6][0], total, number);
					PrintHintText(i, "感染者 %s 掉落 %d 点数,共 %d 份.", g_sZombieName[6][0], total, number);
				}
		}
	}
	if(IsValidClient(victim))
	{
		switch(GetClientTeam(victim))
		{
			case 1:
			{
				for (int i = 1; i <= MaxClients; i++)
				{
					if (IsClientInGame(i) && !IsFakeClient(i))
					{
						switch(GetClientTeam(i))
						{
							case 1:
							{
								int client = iGetBotOfIdlePlayer(i);
								if(client != 0)//闲置死亡时显示的提示.
									if(i != victim)//闲置死亡时显示的提示.
										PrintToChat(i, "\x04[提示]\x05生还者\x03%N\x05已死亡,掉落\x03%d\x05点数\x04,\x05共\x03%d\x05份\x04.", victim, total, number);
									else
										PrintToChat(i, "\x04[提示]\x05你已死亡,掉落\x03%d\x05点数\x04,\x05共\x03%d\x05份\x04,\x05剩余\x03%d\x05点数\x04.", total, number, remaining);
							}
							case 2:
							{
								PrintToChat(i, "\x04[提示]\x05生还者\x03%N\x05已死亡,掉落\x03%d\x05点数\x04,\x05共\x03%d\x05份\x04.", victim, total, number);
							}
						}
					}
				}
			}
			case 2:
			{
				for (int i = 1; i <= MaxClients; i++)
				{
					if (IsClientInGame(i) && !IsFakeClient(i))
					{
						switch(GetClientTeam(i))
						{
							case 1:
							{
								int client = iGetBotOfIdlePlayer(i);
								if(client != 0)//闲置的玩家也能看见提示.
									PrintToChat(i, "\x04[提示]\x05生还者\x03%N\x05已死亡,掉落\x03%d\x05点数\x04,\x05共\x03%d\x05份\x04.", victim, total, number);
							}
							case 2:
							{
								if(i != victim)
									PrintToChat(i, "\x04[提示]\x05生还者\x03%N\x05已死亡,掉落\x03%d\x05点数\x04,\x05共\x03%d\x05份\x04.", victim, total, number);
								else
									PrintToChat(victim, "\x04[提示]\x05你已死亡,掉落\x03%d\x05点数\x04,\x05共\x03%d\x05份\x04,\x05剩余\x03%d\x05点数\x04.", total, number, remaining);
							}
						}
					}
				}
			}
			case 3:
			{
				int iClass = GetEntProp(victim, Prop_Send, "m_zombieClass") - 1;
				
				if(iClass == 7)
				{
					for (int i = 1; i <= MaxClients; i++)
					{
						if (IsClientInGame(i) && GetClientTeam(i) == 2 && !IsFakeClient(i))
						{
							PrintToChat(i, "\x04[提示]\x05感染者\x03%s\x05掉落\x03%d\x05点数\x04,\x05共\x03%d\x05份\x04.", g_sZombieName[iClass][0], total, number);
							PrintHintText(i, "感染者 %s 掉落 %d 点数,共 %d 份.",  g_sZombieName[iClass][0], total, number);
						}
					}
				}
			}
		}
	}
}
//玩家丢弃钞票时调用.
public void OnPlayerDropItMoney(int client, int total, int number, int points)
{
	switch(GetClientTeam(client))
	{
		case 1:
		{
			for (int i = 1; i <= MaxClients; i++)
			{
				if (IsClientInGame(i) && !IsFakeClient(i))
				{
					switch(GetClientTeam(i))
					{
						case 1:
						{
							int victim = iGetBotOfIdlePlayer(i);
							
							if(victim != 0)//闲置的玩家也能看见提示.
								if(i != client)//闲置的玩家也能看见提示.
									PrintToChat(i, "\x04[提示]\x03%N\x05丢弃了\x03%d\x05点数\x04,\x05共\x03%d\x05份\x04.", client, total, number);
								else
									PrintToChat(i, "\x04[提示]\x05你丢弃了\x03%d\x05点数,共\x03%d\x05份\x04,\x05剩余\x03%d\x05点数\x04.", total, number, points);
						}
						case 2:
						{
							PrintToChat(i, "\x04[提示]\x03%N\x05丢弃了\x03%d\x05点数\x04,\x05共\x03%d\x05份\x04.", client, total, number);
						}
					}
				}
			}
		}
		case 2:
		{
			for (int i = 1; i <= MaxClients; i++)
			{
				if (IsClientInGame(i) && !IsFakeClient(i))
				{
					switch(GetClientTeam(i))
					{
						case 1:
						{
							int victim = iGetBotOfIdlePlayer(i);
							if(victim != 0)//闲置的玩家也能看见提示.
								PrintToChat(i, "\x04[提示]\x03%N\x05丢弃了\x03%d\x05点数\x04,\x05共\x03%d\x05份\x04.", client, total, number);
						}
						case 2:
						{
							if(i != client)
								PrintToChat(i, "\x04[提示]\x03%N\x05丢弃了\x03%d\x05点数\x04,\x05共\x03%d\x05份\x04.", client, total, number);
							else
								PrintToChat(client, "\x04[提示]\x05你丢弃了\x03%d\x05点数,共\x03%d\x05份\x04,\x05剩余\x03%d\x05点数\x04.", total, number, points);
						}
					}
				}
			}
		}
	}
}
//判断玩家有效.
stock bool IsValidClient(int client)
{
	return client > 0 && client <= MaxClients && IsClientInGame(client);
}
//返回闲置玩家对应的电脑.
stock int iGetBotOfIdlePlayer(int client)
{
	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i) && IsFakeClient(i) && GetClientTeam(i) == 2 && IsClientIdle(i) == client)
			return i;
	}
	return 0;
}
//返回电脑幸存者对应的玩家.
stock int IsClientIdle(int client)
{
	if (!HasEntProp(client, Prop_Send, "m_humanSpectatorUserID"))
		return 0;

	return GetClientOfUserId(GetEntProp(client, Prop_Send, "m_humanSpectatorUserID"));
}